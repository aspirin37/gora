## Webpack 4 + Vue 2 + Vue-router

### install dependencies
npm install

### serve with hot reload at localhost:8800
npm run dev

### build for production
npm run build
